"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const citasControllers_1 = require("../controllers/citasControllers");
const auth_1 = require("../middleware/auth");
class CitasRoutes {
    constructor() {
        this.router = (0, express_1.Router)();
        this.config();
    }
    config() {
        this.router.get('/mostrarTodasCitas/', auth_1.validarToken, citasControllers_1.citasController.mostrarTodasCitas);
        this.router.get('/listarunaCita/:id', auth_1.validarToken, citasControllers_1.citasController.listarunaCita);
        this.router.post('/crearCita/', auth_1.validarToken, citasControllers_1.citasController.crearCita);
        this.router.put('/actualizarCita/:id', auth_1.validarToken, citasControllers_1.citasController.actualizarCita);
        this.router.delete('/eliminarCita/:id', auth_1.validarToken, citasControllers_1.citasController.eliminarCita);
    }
}
const citasRoutes = new CitasRoutes();
exports.default = citasRoutes.router;
