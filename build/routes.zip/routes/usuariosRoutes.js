"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const usuariosControllers_1 = require("../controllers/usuariosControllers");
const auth_1 = require("../middleware/auth");
class UsuariosRoutes {
    constructor() {
        this.router = (0, express_1.Router)();
        this.config();
    }
    config() {
        this.router.get('/mostrarTodosUsuarios/', auth_1.validarToken, usuariosControllers_1.usuariosController.mostrarTodosUsuarios);
        this.router.get('/obtenerUsuario/:id', auth_1.validarToken, usuariosControllers_1.usuariosController.listOne);
        this.router.get('/ListaUsuarioNombre/:name', auth_1.validarToken, usuariosControllers_1.usuariosController.ListaUsuarioNombre);
        this.router.post('/crearUsuario/', auth_1.validarToken, usuariosControllers_1.usuariosController.createUsuario);
        this.router.put('/actualizarUsuario/:id', auth_1.validarToken, usuariosControllers_1.usuariosController.actualizarUsuario);
        this.router.delete('/eliminarUsuario/:id', auth_1.validarToken, usuariosControllers_1.usuariosController.eliminarUsuario);
        this.router.get('/listarUsuariosRol/:id', auth_1.validarToken, usuariosControllers_1.usuariosController.listarUsuariosRol);
        this.router.post('/ValidarUsuario/', auth_1.validarToken, usuariosControllers_1.usuariosController.ValidarUsuario);
    }
}
const usuariosRoutes = new UsuariosRoutes();
exports.default = usuariosRoutes.router;
