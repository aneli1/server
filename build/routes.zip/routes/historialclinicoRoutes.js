"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const historialclinicoControllers_1 = require("../controllers/historialclinicoControllers");
const auth_1 = require("../middleware/auth");
class HistorialClinicoRoutes {
    constructor() {
        this.router = (0, express_1.Router)();
        this.config();
    }
    config() {
        this.router.get('/mostrarTodoHistorial/', auth_1.validarToken, historialclinicoControllers_1.historialclinicoController.mostrarTodoHistorial);
        this.router.get('/listarunHistorial/:id', auth_1.validarToken, historialclinicoControllers_1.historialclinicoController.listarunHistorial);
        this.router.post('/crearHistorial/', auth_1.validarToken, historialclinicoControllers_1.historialclinicoController.crearHistorial);
        this.router.put('/actualizarHistorial/:id', auth_1.validarToken, historialclinicoControllers_1.historialclinicoController.actualizarHistorial);
        this.router.delete('/eliminarHistorial/:id', auth_1.validarToken, historialclinicoControllers_1.historialclinicoController.eliminarHistorial);
    }
}
const historialclinicoRoutes = new HistorialClinicoRoutes();
exports.default = historialclinicoRoutes.router;
