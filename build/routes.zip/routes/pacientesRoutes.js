"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const pacientesControllers_1 = require("../controllers/pacientesControllers");
const auth_1 = require("../middleware/auth");
class UsuariosRoutes {
    constructor() {
        this.router = (0, express_1.Router)();
        this.config();
    }
    config() {
        this.router.get('/mostrarTodosPacientes/', auth_1.validarToken, pacientesControllers_1.pacientesController.mostrarTodosPacientes);
        this.router.get('/obtenerPaciente/:id', auth_1.validarToken, pacientesControllers_1.pacientesController.listOne);
        this.router.post('/crearPaciente/', auth_1.validarToken, pacientesControllers_1.pacientesController.createPaciente);
        this.router.put('/actualizarPaciente/:id', auth_1.validarToken, pacientesControllers_1.pacientesController.actualizarPaciente);
        this.router.delete('/eliminarPaciente/:id', auth_1.validarToken, pacientesControllers_1.pacientesController.eliminarPaciente);
        this.router.get('/listarPaciente/:id', auth_1.validarToken, pacientesControllers_1.pacientesController.listarPaciente);
        this.router.post('/ValidarPaciente/', auth_1.validarToken, pacientesControllers_1.pacientesController.ValidarPaciente);
    }
}
const usuariosRoutes = new UsuariosRoutes();
exports.default = usuariosRoutes.router;
