"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const consultaControllers_1 = require("../controllers/consultaControllers");
const auth_1 = require("../middleware/auth");
class ConsultaRoutes {
    constructor() {
        this.router = (0, express_1.Router)();
        this.config();
    }
    config() {
        this.router.get('/mostrarTodasConsultas/', auth_1.validarToken, consultaControllers_1.consultaController.mostrarTodasConsultas);
        this.router.get('/listarunaConsulta/:id', auth_1.validarToken, consultaControllers_1.consultaController.listarunaConsulta);
        this.router.post('/crearConsulta/', auth_1.validarToken, consultaControllers_1.consultaController.crearConsulta);
        this.router.put('/actualizarConsulta/:id', auth_1.validarToken, consultaControllers_1.consultaController.actualizarConsulta);
        this.router.delete('/eliminarConsulta/:id', auth_1.validarToken, consultaControllers_1.consultaController.eliminarConsulta);
    }
}
const consultaRoutes = new ConsultaRoutes();
exports.default = consultaRoutes.router;
